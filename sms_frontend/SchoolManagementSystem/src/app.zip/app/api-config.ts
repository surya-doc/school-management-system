export const environment = {
    production: false, // Add your environment-specific flags
    apiUrl: 'http://localhost:8081',
};