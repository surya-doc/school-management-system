import { PhoneFormatterDirective } from './phone-formatter.directive';

describe('PhoneFormatterDirective', () => {
  it('should create an instance', () => {
    const directive = new PhoneFormatterDirective();
    expect(directive).toBeTruthy();
  });
});
