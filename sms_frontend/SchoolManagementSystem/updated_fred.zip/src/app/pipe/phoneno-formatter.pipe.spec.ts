import { PhonenoFormatterPipe } from './phoneno-formatter.pipe';

describe('PhonenoFormatterPipe', () => {
  it('create an instance', () => {
    const pipe = new PhonenoFormatterPipe();
    expect(pipe).toBeTruthy();
  });
});
