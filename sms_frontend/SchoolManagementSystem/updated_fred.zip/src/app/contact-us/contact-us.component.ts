import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit{
  reactiveForm : FormGroup;
  ngOnInit(): void {
      this.reactiveForm = new FormGroup({
        email : new FormControl("",[Validators.email,Validators.required]),
        subject : new FormControl("",[Validators.required]),
        description : new FormControl("",[Validators.required])
      })
  }

  onSubmit(){
    console.log(this.reactiveForm.valid);
  }
}
