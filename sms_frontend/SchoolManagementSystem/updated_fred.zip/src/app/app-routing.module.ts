import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { LoginComponent } from './login/login.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ProfileComponent } from './profile/profile.component';
import { ManageStudentsComponent } from './admin/manage-students/manage-students.component';
import { ManageTeachersComponent } from './admin/manage-teachers/manage-teachers.component';
import { ManageClassComponent } from './admin/manage-class/manage-class.component';
import { ManageNoticesComponent } from './admin/manage-notices/manage-notices.component';
import { ResetEmailComponent } from './reset-email/reset-email.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

const routes: Routes = [
  {path:"",component: HomeComponent},
  {path:"contact-us",component: ContactUsComponent},
  {path:"login",component: LoginComponent},
  {path:"about-us", component:AboutUsComponent},
  {path:"profile", component:ProfileComponent},
  {path:"manage-students", component:ManageStudentsComponent},
  {path:"manage-teachers", component:ManageTeachersComponent},
  {path:"manage-classes", component:ManageClassComponent},
  {path:"manage-notices", component:ManageNoticesComponent},
  {path:"reset-email", component:ResetEmailComponent},
  {path:"reset-password", component:ResetPasswordComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
