import { Component } from '@angular/core';
import { NoticeService_1 } from './admin/service/notice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [NoticeService_1]
})
export class AppComponent {
  title = 'SchoolManagementSystem';
}
