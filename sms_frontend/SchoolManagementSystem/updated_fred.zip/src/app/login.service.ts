import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { environment } from './api-config';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  public loginStatusSubject = new Subject<boolean>();
  constructor(private http: HttpClient) {}

  public generateToken(loginData: any) {
    return this.http.post(`${environment.apiUrl}/auth/login`, loginData);
  }

  public loginUser(token: any) {
    localStorage.setItem('token', token);
    return true;
  }

  public isLoggedIn() {
    let tokenStr = localStorage.getItem('token');
    if (tokenStr == undefined || tokenStr == '' || tokenStr == null) {
      return false;
    } else {
      return true;
    }
  }

  public logout() {
    localStorage.clear();
    return true;
  }

  public getToken() {
    return localStorage.getItem('token');
  }

  public setUser(email: any) {
    this.http.get(`${environment.apiUrl}/api/fetch-user/${email}`).subscribe((data:any)=>{
      localStorage.setItem('user_id', data.id);
      
      localStorage.setItem('role', data.role);
      console.log(data.role, localStorage.getItem('role'));
    });
    
  }

  public getUser() {
    let userStr = localStorage.getItem('user');
    if (userStr !== null) {
      return JSON.parse(userStr);
    } else {
      this.logout();
      return null;
    }
  }

  public getUserRole() {
    return localStorage.getItem('role');
  }
}
