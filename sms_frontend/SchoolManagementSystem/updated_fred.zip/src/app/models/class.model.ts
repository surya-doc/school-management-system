export interface classModel{
    id: number;
    class_name: string;
    min_qualification: string;
}