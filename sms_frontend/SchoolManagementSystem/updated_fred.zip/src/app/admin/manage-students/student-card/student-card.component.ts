import { Component, Input } from '@angular/core';
import { StudentService } from '../service/student.service';

@Component({
  selector: 'app-student-card',
  templateUrl: './student-card.component.html',
  styleUrls: ['./student-card.component.css']
})
export class StudentCardComponent {

  constructor(private studentService: StudentService){}

  @Input() item: any;
  studentDetail = null;
  isPopupOpen = false;
  edit = false
  opType = "Update"
  
  openPopup(): void {
    this.isPopupOpen = true;
  }

  closePopup(): void {
    this.isPopupOpen = false;
  }

  openEdit(): void {
    this.edit = true;
  }

  closeEdit(): void {
    this.edit = false;
  }

  getStudent(){
    this.studentService.getStudent(this.item.user_id).subscribe(
      (response) => {
        this.studentDetail = response;
        // this.item = response;
        console.log('All teachers', this.studentDetail);
      },
      (error) => {
        console.log("Something went wrong", error);
      }
    );
    this.openEdit();
  }

  deleteStudent(){
   let response = window.confirm("Delete student?");
   if(response){
    console.log("Deleted.");
    this.studentService.deleteStudent(this.item.user_id).subscribe(
      (response) => {
        console.log(response);
        this.studentService.classOperationSuccess.next();
      },
      (error) => {
        console.log("Something went wrong", error);
      }
    );
   }
   else{
    console.log("User staies.");
    
   }
  }
}
