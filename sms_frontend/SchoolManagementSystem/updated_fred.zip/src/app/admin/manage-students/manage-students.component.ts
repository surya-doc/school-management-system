import { Component } from '@angular/core';
import { ManageStudentData } from './service/studentData.service';
import { StudentService } from './service/student.service';

@Component({
  selector: 'app-manage-students',
  templateUrl: './manage-students.component.html',
  styleUrls: ['./manage-students.component.css'],
  providers: [ManageStudentData]
})
export class ManageStudentsComponent {
  constructor(private studentsDataService: ManageStudentData, private studentService: StudentService){
    this.studentService.classOperationSuccess.subscribe(() => {
      this.getAllStudents();
    })
  }
  studentsMainData = this.studentsDataService.studentData;

  allStudents = this.studentsMainData;

  edit = false
  sortOptions = ['All', 'Date', 'Active', 'Inactive'];
  opType: string = 'Create'

  openEdit(): void {
    this.edit = true;
  }

  closeEdit(): void {
    this.edit = false;
  }

  ngOnInit(){
    this.getAllStudents();
  }

  getAllStudents(){
    this.studentService.getAllStudents().subscribe(
      (response) => {
        this.studentsMainData = response;
        this.allStudents = this.studentsMainData;
        console.log('All teachers', this.studentsMainData);
      },
      (error) => {
        console.log("Something went wrong", error);
      }
    );
  }
}
