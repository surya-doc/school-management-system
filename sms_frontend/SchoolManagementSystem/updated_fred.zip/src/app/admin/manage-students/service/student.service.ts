import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { environment } from 'src/app/api-config';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  classOperationSuccess = new Subject<void>();
  private apiUrl = `${environment.apiUrl}/api/student`;

  constructor(private http: HttpClient) { }

  getAllStudents(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  getStudent(studentId: number): Observable<any> {
    const url = `${this.apiUrl}/${studentId}`;
    return this.http.get(url);
  }

  createStudent(studentData: FormData): Observable<any> {
    // const url = `${this.apiUrl}/upload`
    console.log(studentData.get('file'), studentData.get('heading'));
    
    return this.http.post(this.apiUrl, studentData);
  }

  updateStudent(studentId: number, updatedData: any): Observable<any> {
    const url = `${this.apiUrl}`;
    return this.http.put(url, updatedData);
  }

  deleteStudent(studentId: number): Observable<any> {
    const url = `${this.apiUrl}/${studentId}`;
    return this.http.delete(url);
  }
}
