import { Component, OnDestroy, OnInit } from '@angular/core';
import { ClassDataService } from './service/class-data.service';
import { Subject } from 'rxjs';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-manage-class',
  templateUrl: './manage-class.component.html',
  styleUrls: ['./manage-class.component.css'],
  providers: [ClassDataService]
})
export class ManageClassComponent implements OnInit {
  private classOperationSuccessSubscription: Subscription;
  constructor(private classDataService: ClassDataService){
    this.classOperationSuccessSubscription = this.classDataService.classOperationSuccess.subscribe(() => {
      this.getAllClasses();
    })
  }
  edit: boolean = false;
  classes: any = [];
  opType = "Create";

  openEdit(): void {
    this.edit = true;
  }

  closeEdit(): void {
    this.edit = false;
  }

  getAllClasses(){
    this.classDataService.getAllclasses().subscribe(
      (response) => {
        this.classes = response;
        console.log('All Classes', this.classes);
      },
      (error) => {
        console.log("Something went wrong", error);
      }
    );
  }

  ngOnInit(){
    this.getAllClasses();
  }
}
