import { Component } from '@angular/core';
import { ManageTeacherData } from './service/teacherDataService.service';
import { TeacherService } from './service/teacher.service';

@Component({
  selector: 'app-manage-teachers',
  templateUrl: './manage-teachers.component.html',
  styleUrls: ['./manage-teachers.component.css'],
  providers: [ManageTeacherData]
})
export class ManageTeachersComponent {
  constructor(private teachersDataService: ManageTeacherData, private teacherService: TeacherService){
    this.teacherService.classOperationSuccess.subscribe(() => {
      this.getAllTeachers();
    })
  }
  teachersMainData = [];
  allTeachers = this.teachersMainData;
  opType: string = 'Create';
  edit = false
  sortOptions = ['All', 'Date', 'Active', 'Inactive'];

  ngOnInit(){
    this.getAllTeachers();
  }

  getAllTeachers(){
    let teachers = this.teacherService.getAllTeachers().subscribe(
      (response) => {
        this.teachersMainData = response;
        this.allTeachers = this.teachersMainData;
        console.log('All teachers', this.teachersMainData);
      },
      (error) => {
        console.log("Something went wrong", error);
      }
    );
  }

  openEdit(): void {
    this.edit = true;
  }

  closeEdit(): void {
    this.edit = false;
  }
}
