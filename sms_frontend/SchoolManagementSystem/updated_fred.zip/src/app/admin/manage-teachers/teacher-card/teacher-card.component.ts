import { Component, Input } from '@angular/core';
import { TeacherService } from '../service/teacher.service';

@Component({
  selector: 'app-teacher-card',
  templateUrl: './teacher-card.component.html',
  styleUrls: ['./teacher-card.component.css']
})
export class TeacherCardComponent {

  constructor(private teacherService: TeacherService){}

  @Input() item: any;
  teacherDetail = null;
  opType: string = 'Update';

  isPopupOpen = false;
  edit = false

  closePopup(): void {
    this.isPopupOpen = false;
  }

  openEdit(): void {
    this.teacherService.getTeacher(this.item.user_id).subscribe(
      (response) => {
        this.teacherDetail = response;
        // this.item = response;
        console.log('All teachers', this.teacherDetail);
      },
      (error) => {
        console.log("Something went wrong", error);
      }
    );
    
    this.edit = true;
  }

  closeEdit(): void {
    this.edit = false;
  }

  getTeacher(){
    this.teacherService.getTeacher(this.item.user_id).subscribe(
      (response) => {
        this.teacherDetail = response;
        this.item = response;
        console.log('All teachers', this.teacherDetail);
      },
      (error) => {
        console.log("Something went wrong", error);
      }
    );
    this.isPopupOpen = true;
  }

  deleteTeacher(){
   let response = window.confirm("Delete teacher?");
   if(response){
    console.log("Deleted.");
    this.teacherService.deleteTeacher(this.item.user_id).subscribe(
      (response) => {
        console.log(response);
        this.teacherService.classOperationSuccess.next();
      },
      (error) => {
        console.log("Something went wrong", error);
      }
    );
   }
   else{
    console.log("User staies.");
    
   }
  }
}
