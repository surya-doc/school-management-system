import { Component } from '@angular/core';
import { Observable, Subject, Subscription } from 'rxjs';
import { DropdownComponent } from '../dropdown/dropdown.component';
import { NoticeService_1 } from '../service/notice.service';
import { ManageNoticeData } from './service/manageNoticeData.service';
import { NoticeCRUD } from './service/noticeCRUD.service';
import { HttpClient } from '@angular/common/http';
import { NoticeService } from './service/notice.service';

@Component({
  selector: 'app-manage-notices',
  templateUrl: './manage-notices.component.html',
  styleUrls: ['./manage-notices.component.css'],
  providers: [ManageNoticeData, NoticeCRUD]
})
export class ManageNoticesComponent {
  dummyNoticeMain = [];
  dummyNotices = [];
  sortOptions = ['All', 'Date', 'Active', 'Inactive'];
  opType = "Create"
  constructor(private noticeDataService: ManageNoticeData, private notice: NoticeService, private http: HttpClient){
    this.notice.classOperationSuccess.subscribe(() => {
      this.getAllNotices();
    })
  }
  edit = false
  
  openEdit(): void {
    this.edit = true;
  }

  closeEdit(): void {
    this.edit = false;
  }

  getAllNotices(){
    this.notice.getAllNotices().subscribe(
      (response) => {
        console.log('File uploaded successfully', response);
        this.dummyNoticeMain = response
        this.dummyNotices = response;
      },
      (error) => {
        console.log("Something went wrong", error);       
      }
    );
  }

  ngOnInit(): void {
    this.getAllNotices();
    this.notice.selectedOptionSubject.subscribe((value) => {
      console.log(value);
      this.dummyNotices = this.dummyNoticeMain;
      if(value === "Date"){
        this.dummyNotices = this.dummyNotices.sort((a, b) => {
          const date_1 = new Date(a.startDate);
          const date_2 = new Date(b.startDate);
          if(date_1 > date_2) {
            return -1;
          }
          if(date_1 < date_2) {
            return 1;
          }
          return 0;
        });
      }
      else if(value === "Active"){
        this.dummyNotices = this.dummyNotices.filter((notice) => {
          return notice.active === true;
        })
      }
      else if(value === "Inactive"){
        this.dummyNotices = this.dummyNotices.filter((notice) => {
          return notice.active === false;
        })
      }
      else if(value === "All"){
        this.dummyNotices = this.dummyNoticeMain;
      }
    })
  }








  imageSrc: string = ''; // Store the image source URL

  getImage(): Observable<Blob> {
    return this.http.get('http://localhost:8080/notices/download', {
      responseType: 'blob',
    });
  }

  imageToShow: any;
  createImageFromBlob(image: Blob) {
    let reader = new FileReader();
    reader.addEventListener(
      'load',
      () => {
        this.imageToShow = reader.result;
      },
      false
    );

    if (image) {
      reader.readAsDataURL(image);
    }
  }
}
