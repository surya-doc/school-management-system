import { Injectable } from "@angular/core";
import { Notice } from "src/app/models/notice.model";

@Injectable()
export class ManageNoticeData{
    dummyNoticeMain: Notice[] = [
        {
          heading: 'Notice 1',
          description: 'This is the first notice description This is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice descriptionThis is the first notice description.',
          startDate: new Date('2023-10-10'),
          expiryDate: new Date('2023-11-10'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        },
        {
          heading: 'Notice 2',
          description: 'This is the second notice description.',
          startDate: new Date('2023-09-15'),
          expiryDate: new Date('2023-10-15'),
          active: false
        },
        {
          heading: 'Notice 3',
          description: 'This is the third notice description.',
          startDate: new Date('2023-11-01'),
          expiryDate: new Date('2023-12-01'),
          active: true
        }
    ];
}