import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NavComponent } from './nav/nav.component';
import { FooterComponent } from './footer/footer.component';
import { GalleryComponent } from './gallery/gallery.component';
import { DragScrollModule } from 'ngx-drag-scroll';
import { ClassScrollerComponent } from './class-scroller/class-scroller.component';
import { NoticeBoardComponent } from './notice-board/notice-board.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ProfileComponent } from './profile/profile.component';

import { AdminComponent } from './admin/admin.component';
import { ManageNoticesComponent } from './admin/manage-notices/manage-notices.component';
import { ManageTeachersComponent } from './admin/manage-teachers/manage-teachers.component';
import { ManageStudentsComponent } from './admin/manage-students/manage-students.component';
import { ManageClassComponent } from './admin/manage-class/manage-class.component';
import { NoticeCardComponent } from './admin/manage-notices/notice-card/notice-card.component';
import {MatIconModule} from '@angular/material/icon';
import {MatDialogModule} from '@angular/material/dialog';
import { NoticeDetailComponent } from './admin/manage-notices/notice-detail/notice-detail.component';
import {MatButtonModule} from '@angular/material/button';
import { CreateNoticeComponent } from './admin/manage-notices/create-notice/create-notice.component';
import { DropdownComponent } from './admin/dropdown/dropdown.component';
import { ClassCardComponent } from './admin/manage-class/class-card/class-card.component';
import { ClassCreateUpdateComponent } from './admin/manage-class/class-create-update/class-create-update.component';
import { StudentCardComponent } from './admin/manage-students/student-card/student-card.component';
import { StudentDetailsComponent } from './admin/manage-students/student-details/student-details.component';
import { StudentCreateUpdateComponent } from './admin/manage-students/student-create-update/student-create-update.component';
import { PhonenoFormatterPipe } from './pipe/phoneno-formatter.pipe';
import { PhoneFormatterDirective } from './directives/phone-formatter.directive';
import { TeacherCardComponent } from './admin/manage-teachers/teacher-card/teacher-card.component';
import { TeacherCreateUpdateComponent } from './admin/manage-teachers/teacher-create-update/teacher-create-update.component';
import { TeacherDetailsComponent } from './admin/manage-teachers/teacher-details/teacher-details.component';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { JwtInterceptor } from './jwt-interceptor';
import { ResetEmailComponent } from './reset-email/reset-email.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavComponent,
    FooterComponent,
    GalleryComponent,
    ClassScrollerComponent,
    NoticeBoardComponent,
    ContactUsComponent,
    LoginComponent,
    AboutUsComponent,
    ProfileComponent,
    AdminComponent,
    ManageNoticesComponent,
    ManageTeachersComponent,
    ManageStudentsComponent,
    ManageClassComponent,
    NoticeCardComponent,
    NoticeDetailComponent,
    CreateNoticeComponent,
    DropdownComponent,
    ClassCardComponent,
    ClassCreateUpdateComponent,
    StudentCardComponent,
    StudentDetailsComponent,
    StudentCreateUpdateComponent,
    PhonenoFormatterPipe,
    PhoneFormatterDirective,
    TeacherCardComponent,
    TeacherCreateUpdateComponent,
    TeacherDetailsComponent,
    ResetEmailComponent,
    ResetPasswordComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    DragScrollModule,
    MatIconModule,
    MatDialogModule,
    MatButtonModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JwtInterceptor,
      multi: true,
    },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
