import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { debounceTime } from 'rxjs';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit{
  collapsed: boolean =true;
  dropdown: boolean = false;
  role: String;
  LoggedIn: boolean = false;
  constructor(private loginService:LoginService){
    this.loginService.loginStatusSubject.subscribe(
      (data:any)=>{
        this.LoggedIn = true;
        this.role = localStorage.getItem('role');
        console.log(this.role, localStorage.getItem('role'));
        
      }
    )
  }

  ngOnInit(): void {
    this.role = this.loginService.getUserRole();
    this.LoggedIn = this.loginService.isLoggedIn();
    console.log(this.LoggedIn);
    
  }

  toggleCollapsed(): void {
    console.log("button clicked");
    this.collapsed = !this.collapsed;
  }

  toggleDropDown(): void {
    this.dropdown = !this.dropdown;
    console.log(this.dropdown);
    
  }
}
